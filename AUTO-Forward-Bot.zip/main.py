from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters
import os

BOT_TOKEN = os.getenv("8837928390:AAHZceKWEsyDu4IKqFXvyQGXO2atDsTPhKs")
CHANNEL_ID = "@BLAND_OP_FEEDBACK"

async def feedback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text

    message = f"""📩 New Feedback

👤 Name: {@BLANDFEEDBACK_bot}
🆔 User ID: {5232377996}

💬 Feedback:
{text}
"""
    await context.bot.send_message(chat_id=CHANNEL_ID, text=message)
    await update.message.reply_text("✅ Thank you! Your feedback has been sent.")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, feedback))

print("Bot Started...")
app.run_polling()
