# BLAND_OP Feedback Bot

1. Create a GitHub repository and upload these files.
2. Create a Railway project and connect the repository.
3. Add an environment variable:
   BOT_TOKEN=YOUR_NEW_BOT_TOKEN
4. Add the bot as an Admin in @BLAND_OP_FEEDBACK with permission to post messages.
5. Deploy.
